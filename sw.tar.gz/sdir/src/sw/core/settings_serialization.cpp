/*
 * SW - Build System and Package Manager
 * Copyright (C) 2017-2020 Egor Pugin
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#pragma once

#include <boost/serialization/access.hpp>
#include <boost/serialization/split_member.hpp>

#include "settings.h"

#include <boost/serialization/map.hpp>
#include <boost/serialization/vector.hpp>
#include <primitives/exceptions.h>

#include <fstream>

// last
#include <sw/support/serialization.h>

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4005) // warning C4005: 'XXX': macro redefinition
#endif

namespace sw
{

TargetSettings loadSettings(const path &archive_fn, int type)
{
    return deserialize<TargetSettings>(archive_fn, type);
}

void saveSettings(const path &archive_fn, const TargetSettings &s, int type)
{
    serialize(archive_fn, s, type);
}

} // namespace sw
